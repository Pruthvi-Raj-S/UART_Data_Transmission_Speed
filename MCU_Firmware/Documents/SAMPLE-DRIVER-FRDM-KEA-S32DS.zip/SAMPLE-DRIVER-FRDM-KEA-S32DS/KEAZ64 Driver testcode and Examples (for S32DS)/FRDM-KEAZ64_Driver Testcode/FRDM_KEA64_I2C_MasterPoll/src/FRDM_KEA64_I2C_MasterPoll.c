
/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2013 Freescale Semiconductor, Inc.
* ALL RIGHTS RESERVED.
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* @file FRDM_KEA64_I2C_MasterPoll.c
*
* @author Freescale
*
* @brief providing framework of demo cases for MCU.
*
*
*	This example provides a template for I2C master with poll mode.
*	it cycle to transfer a frame data(1 byte) and show it on terminal.
*	it also provide a template for how to initialize I2C module.
*
*	- Requirement for demo:
*	1. connect two boards with PTA2(SDA - J2_17), PTA3(SCL - J2_19), and (GND - J2_13)
*	2. connect the grounds of both Master and Slave devices.
*
*******************************************************************************/

#include "ics.h"
#include "uart.h"
#include "i2c.h"
#include "gpio.h"
#include"derivative.h"
/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Constants and macros
******************************************************************************/
#define I2C_SLAVE_ADDRESS          0x50
/******************************************************************************
* Local types
******************************************************************************/

/******************************************************************************
* Local function prototypes
******************************************************************************/

/******************************************************************************
* Local variables
******************************************************************************/
uint8_t u8I2C_SendBuff[64];
uint8_t u8I2C_ReceiveBuff[64];
/******************************************************************************
* Local functions
******************************************************************************/
int main (void);
/******************************************************************************
* Global functions
******************************************************************************/


/********************************************************************/
int main (void)
{
    I2C_ConfigType  I2C_Config = {{0}};
    volatile uint32_t i,j;

    for(i=0;i<0xfff;i++);

    /* Perform processor initialization */
	ICS_ConfigType ICS_set={0};		/* Declaration of ICS_setup structure */
	ICS_set.u8ClkMode=ICS_CLK_MODE_FEI;
	ICS_set.bdiv=0;
	ICS_Init(&ICS_set);             /*Initialization of clock at 48Mhz*/

	UART_ConfigType UART_Config={{0}};

	UART_Config.sctrl1settings.bits.bM=0;  	/* 8 bit mode*/
	UART_Config.sctrl1settings.bits.bPe=0;	/* No hardware parity generation or checking*/
	UART_Config.bSbns=0;					/* One stop bit*/
	UART_Config.sctrl2settings.bits.bRe=1;	/* Enable Receiver*/
	UART_Config.sctrl2settings.bits.bTe=1;	/* Enable Transmitter*/
	UART_Config.u32SysClkHz = 24000000;   	/* Bus clock in Hz*/
	UART_Config.u32Baudrate = 115200;     	/* UART baud rate */

	UART_Init(UART2,&UART_Config);			/*Initialization of UART utilities*/

  	printf("\r\nRunning the FRDM_KEA128_I2C_MasterPoll project.\r\n");

    ENABLE_PULLUP(PTA,PTA2);	/* Enable I2C0 SDA pin pull up */
    ENABLE_PULLUP(PTA,PTA3);	/* Enable I2C0 SCL pin pull up */

    /* Initialize I2C module with poll mode */
  	I2C_Config.u16Slt = 0;
  	I2C_Config.u16F = 0x1F; /* Baud rate at 100 kbit/sec = 24M / (1 * 240), MULT = 1 , ICR = 31 */
    I2C_Config.sSetting.bIntEn = 0;
    I2C_Config.sSetting.bI2CEn = 1;

    I2C_Init(I2C0,&I2C_Config );

    CONFIG_PIN_AS_GPIO(PTE,PTE7,OUTPUT);
    OUTPUT_CLEAR(PTE,PTE7);

  	for(i=0;i<64;i++)
	{
		u8I2C_SendBuff[i] = i;
	}

	while(1)
	{
		I2C_MasterSendWait(I2C0,I2C_SLAVE_ADDRESS,&u8I2C_SendBuff[0],64);
		I2C_MasterReadWait(I2C0,I2C_SLAVE_ADDRESS,&u8I2C_ReceiveBuff[0],64);
		printf("Read data from I2C slave:\r\n");
		for(i=0;i<8;i++)
		{
			for(j=0;j<8;j++)
			{
				printf("0x%x,", u8I2C_ReceiveBuff[i*8+j]);
			}

			printf("\r\n");
		}
		u8I2C_SendBuff[0]++;
		for(i=1;i<64;i++)
		{
			u8I2C_SendBuff[i] = i+u8I2C_SendBuff[0];
		}
		for(i=0;i<0xfffff;i++);
	}
}


